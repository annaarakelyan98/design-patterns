package com.designPatterns.creational.factory.abstractClass;

public abstract class CityName {
    abstract void getName();
}
