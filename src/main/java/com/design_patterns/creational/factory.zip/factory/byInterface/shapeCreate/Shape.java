package com.designPatterns.creational.factory.byInterface.shapeCreate;

public interface Shape {
    void draw();
}
