package com.designPatterns.creational.factory.abstractClass;

public class Yerevan extends CityName {
    @Override
    void getName() {
        System.out.println("Yerevan is the capital city of Armenia!");
    }
}
